//! The metric vocabulary sent to `POST /v1/telemetry`.
//!
//! # Rules for changing anything in this file
//!
//! Consumers assign each property a field type on first sight and cannot change it in place
//! afterwards. That makes the constraints asymmetric:
//!
//! - Adding a key is safe.
//! - Changing an existing key's JSON type is **not**: it breaks ingestion for every document carrying the new type, and
//!   recovering means rebuilding the stored data. If a key's meaning or unit changes, introduce a new key instead
//!   (`duration_ms` never becomes a float; a microsecond variant would be `duration_us`).
//! - Removing a key silently breaks dashboards and alerts.
//!
//! `test_upload_key_set_is_exact` / `test_download_key_set_is_exact` pin the key sets and
//! `test_numeric_types_stable` pins the types, so any of the above fails the build rather than
//! production.
//!
//! Every value is a `u64`, `f64`, `bool`, or `String` - never null, never nested, never an array.
//! No file names, paths, hashes, repository ids, or user ids appear here; the server derives
//! identity from the request's JWT.

use serde::Serialize;
use xet_client::cas_client::{Direction, TransferTelemetry, XorbUploadPathTotals};

use super::outcome::Outcome;
use crate::deduplication::DeduplicationMetrics;
use crate::progress_tracking::GroupProgressReport;

/// Bumped when keys are added. Query-side branching hangs off this; it is not a wire version.
pub const TELEMETRY_SCHEMA_VERSION: u64 = 2;

/// Divides, guaranteeing a finite `f64`.
///
/// `serde_json` serializes NaN and infinity as `null`, which would break the type stability the
/// module docs describe - a single such document can poison a consumer's field type. Every ratio and
/// rate in this file goes through here; there are no exceptions.
///
/// Rounded to four decimal places to keep documents small and diffs readable.
#[inline]
pub(crate) fn ratio(numerator: u64, denominator: u64) -> f64 {
    if denominator == 0 {
        return 0.0;
    }
    finite(numerator as f64 / denominator as f64)
}

/// Bytes per second over a millisecond duration, guaranteed finite.
#[inline]
pub(crate) fn rate_bps(bytes: u64, duration_ms: u64) -> f64 {
    if duration_ms == 0 {
        return 0.0;
    }
    finite(bytes as f64 * 1000.0 / duration_ms as f64)
}

#[inline]
fn finite(value: f64) -> f64 {
    if value.is_finite() {
        (value * 10_000.0).round() / 10_000.0
    } else {
        0.0
    }
}

/// Keys present in every telemetry document, in both directions, always.
#[derive(Debug, Clone, Serialize)]
pub struct CommonMetrics {
    pub schema_version: u64,
    pub direction: &'static str,
    /// Unique per transfer. A single `XetSession` id can cover both an upload commit and a
    /// download group, so `session_id` alone does not identify a transfer.
    pub transfer_id: String,
    /// Exactly one document per `transfer_id` carries `true`. Filter on it to get one row per
    /// transfer without any group-by.
    pub terminal: bool,
    /// 0 for the first document; increments per heartbeat.
    pub seq: u64,

    pub client_version: &'static str,
    pub os: &'static str,
    pub arch: &'static str,
    pub cpu_count: u64,
    /// Host component only.
    pub endpoint_host: String,

    pub duration_ms: u64,
    pub outcome: &'static str,
    pub error_class: &'static str,

    pub n_files: u64,
    /// Logical bytes, before dedup and compression.
    pub total_bytes: u64,
    pub total_bytes_completed: u64,
    /// Bytes actually moved over the wire.
    pub transfer_bytes: u64,
    pub transfer_bytes_completed: u64,
    /// Wire throughput over the whole transfer. Deterministic, unlike the EWMA below.
    pub throughput_bps: f64,
    pub logical_throughput_bps: f64,
    /// The client's own EWMA estimate, for comparison against the wall-clock figures. Zero rather
    /// than absent when the sampler never had enough observations.
    pub ewma_throughput_bps: f64,

    pub peak_concurrency: u64,
}

/// What the caller must supply that cannot be read off the transfer or the progress report.
pub struct CommonInputs<'a> {
    pub direction: Direction,
    pub outcome: Outcome,
    pub error_class: &'static str,
    pub terminal: bool,
    pub seq: u64,
    pub n_files: u64,
    pub progress: &'a GroupProgressReport,
}

/// Identity and timing, snapshotted from [`TransferTelemetry`].
///
/// Taken as plain data rather than a `&TransferTelemetry` so this module stays independently
/// testable: `TransferTelemetry` needs a `XetContext` and a live HTTP client to construct, which a
/// payload unit test has no business setting up.
pub struct TransferIdentity {
    pub transfer_id: String,
    pub endpoint_host: String,
    pub duration_ms: u64,
    pub peak_concurrency: u64,
}

impl From<&TransferTelemetry> for TransferIdentity {
    fn from(telemetry: &TransferTelemetry) -> Self {
        Self {
            transfer_id: telemetry.transfer_id().to_owned(),
            endpoint_host: telemetry.endpoint_host().to_owned(),
            // Saturating: `as u64` on an out-of-range u128 would wrap.
            duration_ms: u64::try_from(telemetry.elapsed().as_millis()).unwrap_or(u64::MAX),
            peak_concurrency: telemetry.peak_concurrency(),
        }
    }
}

/// Xorb uploads per upload path, snapshotted from [`TransferTelemetry`].
#[derive(Debug, Clone, Copy, Default)]
pub struct XorbUploadPaths {
    pub grant: XorbUploadPathTotals,
    pub direct: XorbUploadPathTotals,
    pub grant_fallbacks: u64,
    pub grant_unreachable: u64,
}

impl From<&TransferTelemetry> for XorbUploadPaths {
    fn from(telemetry: &TransferTelemetry) -> Self {
        Self {
            grant: telemetry.grant_xorb_uploads(),
            direct: telemetry.direct_xorb_uploads(),
            grant_fallbacks: telemetry.grant_fallbacks(),
            grant_unreachable: telemetry.grant_unreachable(),
        }
    }
}

impl CommonMetrics {
    pub fn new(identity: TransferIdentity, inputs: CommonInputs<'_>) -> Self {
        let progress = inputs.progress;
        let duration_ms = identity.duration_ms;

        Self {
            schema_version: TELEMETRY_SCHEMA_VERSION,
            direction: inputs.direction.as_str(),
            transfer_id: identity.transfer_id,
            terminal: inputs.terminal,
            seq: inputs.seq,

            client_version: env!("CARGO_PKG_VERSION"),
            os: std::env::consts::OS,
            arch: std::env::consts::ARCH,
            cpu_count: std::thread::available_parallelism().map(|n| n.get() as u64).unwrap_or(0),
            endpoint_host: identity.endpoint_host,

            duration_ms,
            outcome: inputs.outcome.as_str(),
            error_class: inputs.error_class,

            n_files: inputs.n_files,
            total_bytes: progress.total_bytes,
            total_bytes_completed: progress.total_bytes_completed,
            transfer_bytes: progress.total_transfer_bytes,
            transfer_bytes_completed: progress.total_transfer_bytes_completed,
            throughput_bps: rate_bps(progress.total_transfer_bytes_completed, duration_ms),
            logical_throughput_bps: rate_bps(progress.total_bytes_completed, duration_ms),
            ewma_throughput_bps: progress.total_transfer_bytes_completion_rate.map(finite).unwrap_or(0.0),

            peak_concurrency: identity.peak_concurrency,
        }
    }
}

/// Upload documents: [`CommonMetrics`] plus dedup effectiveness and shard finalization.
#[derive(Debug, Clone, Serialize)]
pub struct UploadMetrics {
    #[serde(flatten)]
    pub common: CommonMetrics,

    pub dedup_bytes: u64,
    pub new_bytes: u64,
    pub global_dedup_bytes: u64,
    pub defrag_prevented_dedup_bytes: u64,
    pub total_chunks: u64,
    pub dedup_chunks: u64,
    pub new_chunks: u64,
    pub global_dedup_chunks: u64,
    pub defrag_prevented_dedup_chunks: u64,

    pub xorb_bytes_uploaded: u64,
    pub shard_bytes_uploaded: u64,

    /// Xorbs stored through an upload grant (grant, upload, commit).
    pub grant_xorb_upload_count: u64,
    /// Serialized bytes of the xorbs above, once per xorb however many grant attempts it took.
    pub grant_xorb_upload_bytes: u64,
    /// Summed per-xorb time from the first grant request to the commit; exceeds wall-clock time
    /// when uploads overlap.
    pub grant_xorb_upload_ms: u64,
    /// Xorbs uploaded through `POST /v1/xorbs`, including fallbacks from upload grants.
    pub direct_xorb_upload_count: u64,
    /// Serialized bytes of the xorbs above.
    pub direct_xorb_upload_bytes: u64,
    /// Summed per-xorb `POST /v1/xorbs` time, excluding any grant attempts before a fallback.
    pub direct_xorb_upload_ms: u64,
    /// Xorbs for which an upload grant was issued but that were still uploaded through `POST /v1/xorbs`. A
    /// subset of `direct_xorb_upload_count`; xorbs uploaded directly because grants are not offered are excluded.
    pub grant_fallback_count: u64,
    /// Grant fallbacks after a failed upload to the grant URL, such as a connection, DNS, or timeout error. A subset
    /// of `grant_fallback_count`.
    pub grant_unreachable_count: u64,

    pub shards_total: u64,
    pub shards_completed: u64,
    pub shard_validation_entries: u64,

    /// Share of logical bytes avoided by dedup.
    pub dedup_ratio: f64,
    /// Compressed xorb bytes over the new bytes that produced them.
    pub compression_ratio: f64,

    /// Chunking, hashing, and xorb upload: session start until `finalize` was called.
    pub ingest_ms: u64,
    /// Shard consolidation, upload, and registration.
    pub finalize_ms: u64,
}

impl UploadMetrics {
    pub fn new(
        common: CommonMetrics,
        dedup: &DeduplicationMetrics,
        progress: &GroupProgressReport,
        xorb_upload_paths: XorbUploadPaths,
        ingest_ms: u64,
        finalize_ms: u64,
    ) -> Self {
        // `shard` is None for dry runs and for callers that predate the shard progress section;
        // zero is the correct reading in both cases, and keeps the key set fixed.
        let shard = progress.shard.as_ref();

        Self {
            dedup_bytes: dedup.deduped_bytes,
            new_bytes: dedup.new_bytes,
            global_dedup_bytes: dedup.deduped_bytes_by_global_dedup,
            defrag_prevented_dedup_bytes: dedup.defrag_prevented_dedup_bytes,
            total_chunks: dedup.total_chunks,
            dedup_chunks: dedup.deduped_chunks,
            new_chunks: dedup.new_chunks,
            global_dedup_chunks: dedup.deduped_chunks_by_global_dedup,
            defrag_prevented_dedup_chunks: dedup.defrag_prevented_dedup_chunks,

            xorb_bytes_uploaded: dedup.xorb_bytes_uploaded,
            shard_bytes_uploaded: dedup.shard_bytes_uploaded,

            grant_xorb_upload_count: xorb_upload_paths.grant.count,
            grant_xorb_upload_bytes: xorb_upload_paths.grant.bytes,
            grant_xorb_upload_ms: xorb_upload_paths.grant.duration_ms,
            direct_xorb_upload_count: xorb_upload_paths.direct.count,
            direct_xorb_upload_bytes: xorb_upload_paths.direct.bytes,
            direct_xorb_upload_ms: xorb_upload_paths.direct.duration_ms,
            grant_fallback_count: xorb_upload_paths.grant_fallbacks,
            grant_unreachable_count: xorb_upload_paths.grant_unreachable,

            shards_total: shard.map(|s| s.total_shards as u64).unwrap_or(0),
            shards_completed: shard.map(|s| s.total_shards_completed as u64).unwrap_or(0),
            shard_validation_entries: shard.map(|s| s.total_shard_validation_entries).unwrap_or(0),

            dedup_ratio: ratio(dedup.deduped_bytes, dedup.total_bytes),
            compression_ratio: ratio(dedup.xorb_bytes_uploaded, dedup.new_bytes),

            ingest_ms,
            finalize_ms,
            common,
        }
    }
}

/// Download documents: [`CommonMetrics`] plus how much the wire bytes expanded on disk.
#[derive(Debug, Clone, Serialize)]
pub struct DownloadMetrics {
    #[serde(flatten)]
    pub common: CommonMetrics,

    /// Logical bytes produced per wire byte - dedup and compression combined, from the
    /// downloader's side.
    pub expansion_ratio: f64,
}

impl DownloadMetrics {
    pub fn new(common: CommonMetrics) -> Self {
        Self {
            expansion_ratio: ratio(common.total_bytes_completed, common.transfer_bytes_completed),
            common,
        }
    }
}

#[cfg(test)]
mod tests {
    use serde_json::Value;

    use super::super::outcome::ERROR_CLASS_NONE;
    use super::*;

    /// The upload key set. Changing this list is a schema change - read the module docs first.
    const UPLOAD_KEYS: &[&str] = &[
        "arch",
        "client_version",
        "compression_ratio",
        "cpu_count",
        "dedup_bytes",
        "dedup_chunks",
        "dedup_ratio",
        "defrag_prevented_dedup_bytes",
        "defrag_prevented_dedup_chunks",
        "direct_xorb_upload_bytes",
        "direct_xorb_upload_count",
        "direct_xorb_upload_ms",
        "direction",
        "duration_ms",
        "endpoint_host",
        "error_class",
        "ewma_throughput_bps",
        "finalize_ms",
        "global_dedup_bytes",
        "global_dedup_chunks",
        "grant_fallback_count",
        "grant_unreachable_count",
        "grant_xorb_upload_bytes",
        "grant_xorb_upload_count",
        "grant_xorb_upload_ms",
        "ingest_ms",
        "logical_throughput_bps",
        "n_files",
        "new_bytes",
        "new_chunks",
        "os",
        "outcome",
        "peak_concurrency",
        "schema_version",
        "seq",
        "shard_bytes_uploaded",
        "shard_validation_entries",
        "shards_completed",
        "shards_total",
        "terminal",
        "throughput_bps",
        "total_bytes",
        "total_bytes_completed",
        "total_chunks",
        "transfer_bytes",
        "transfer_bytes_completed",
        "transfer_id",
        "xorb_bytes_uploaded",
    ];

    /// The download key set. Changing this list is a schema change - read the module docs first.
    const DOWNLOAD_KEYS: &[&str] = &[
        "arch",
        "client_version",
        "cpu_count",
        "direction",
        "duration_ms",
        "endpoint_host",
        "error_class",
        "ewma_throughput_bps",
        "expansion_ratio",
        "logical_throughput_bps",
        "n_files",
        "os",
        "outcome",
        "peak_concurrency",
        "schema_version",
        "seq",
        "terminal",
        "throughput_bps",
        "total_bytes",
        "total_bytes_completed",
        "transfer_bytes",
        "transfer_bytes_completed",
        "transfer_id",
    ];

    /// The JSON type every key must always have. A key that changes type here breaks the
    /// consumer's field type and starts breaking ingestion.
    #[derive(Debug, Clone, Copy, PartialEq, Eq)]
    enum Kind {
        U64,
        F64,
        Bool,
        Str,
    }

    const TYPES: &[(&str, Kind)] = &[
        ("arch", Kind::Str),
        ("client_version", Kind::Str),
        ("compression_ratio", Kind::F64),
        ("cpu_count", Kind::U64),
        ("dedup_bytes", Kind::U64),
        ("dedup_chunks", Kind::U64),
        ("dedup_ratio", Kind::F64),
        ("defrag_prevented_dedup_bytes", Kind::U64),
        ("defrag_prevented_dedup_chunks", Kind::U64),
        ("direct_xorb_upload_bytes", Kind::U64),
        ("direct_xorb_upload_count", Kind::U64),
        ("direct_xorb_upload_ms", Kind::U64),
        ("direction", Kind::Str),
        ("duration_ms", Kind::U64),
        ("endpoint_host", Kind::Str),
        ("error_class", Kind::Str),
        ("ewma_throughput_bps", Kind::F64),
        ("expansion_ratio", Kind::F64),
        ("finalize_ms", Kind::U64),
        ("global_dedup_bytes", Kind::U64),
        ("global_dedup_chunks", Kind::U64),
        ("grant_fallback_count", Kind::U64),
        ("grant_unreachable_count", Kind::U64),
        ("grant_xorb_upload_bytes", Kind::U64),
        ("grant_xorb_upload_count", Kind::U64),
        ("grant_xorb_upload_ms", Kind::U64),
        ("ingest_ms", Kind::U64),
        ("logical_throughput_bps", Kind::F64),
        ("n_files", Kind::U64),
        ("new_bytes", Kind::U64),
        ("new_chunks", Kind::U64),
        ("os", Kind::Str),
        ("outcome", Kind::Str),
        ("peak_concurrency", Kind::U64),
        ("schema_version", Kind::U64),
        ("seq", Kind::U64),
        ("shard_bytes_uploaded", Kind::U64),
        ("shard_validation_entries", Kind::U64),
        ("shards_completed", Kind::U64),
        ("shards_total", Kind::U64),
        ("terminal", Kind::Bool),
        ("throughput_bps", Kind::F64),
        ("total_bytes", Kind::U64),
        ("total_bytes_completed", Kind::U64),
        ("total_chunks", Kind::U64),
        ("transfer_bytes", Kind::U64),
        ("transfer_bytes_completed", Kind::U64),
        ("transfer_id", Kind::Str),
        ("xorb_bytes_uploaded", Kind::U64),
    ];

    fn identity() -> TransferIdentity {
        TransferIdentity {
            transfer_id: "0199-transfer".into(),
            endpoint_host: "cas.example.com".into(),
            duration_ms: 4_000,
            peak_concurrency: 16,
        }
    }

    fn inputs(progress: &GroupProgressReport) -> CommonInputs<'_> {
        CommonInputs {
            direction: Direction::Upload,
            outcome: Outcome::Ok,
            error_class: ERROR_CLASS_NONE,
            terminal: true,
            seq: 3,
            n_files: 7,
            progress,
        }
    }

    /// Values chosen so no field is coincidentally zero: a zero `f64` still serializes as `0.0`,
    /// but distinct values make a mis-mapped field obvious.
    fn common() -> CommonMetrics {
        CommonMetrics {
            schema_version: TELEMETRY_SCHEMA_VERSION,
            direction: Direction::Upload.as_str(),
            transfer_id: "0199-transfer".into(),
            terminal: true,
            seq: 3,
            client_version: "1.2.3",
            os: "linux",
            arch: "x86_64",
            cpu_count: 8,
            endpoint_host: "cas.example.com".into(),
            duration_ms: 4_000,
            outcome: Outcome::Ok.as_str(),
            error_class: ERROR_CLASS_NONE,
            n_files: 7,
            total_bytes: 1_000,
            total_bytes_completed: 900,
            transfer_bytes: 500,
            transfer_bytes_completed: 400,
            throughput_bps: 100.0,
            logical_throughput_bps: 225.0,
            ewma_throughput_bps: 111.5,
            peak_concurrency: 16,
        }
    }

    fn dedup() -> DeduplicationMetrics {
        DeduplicationMetrics {
            total_bytes: 1_000,
            deduped_bytes: 400,
            new_bytes: 600,
            deduped_bytes_by_global_dedup: 100,
            defrag_prevented_dedup_bytes: 10,
            total_chunks: 50,
            deduped_chunks: 20,
            new_chunks: 30,
            deduped_chunks_by_global_dedup: 5,
            defrag_prevented_dedup_chunks: 1,
            xorb_bytes_uploaded: 300,
            shard_bytes_uploaded: 25,
            total_bytes_uploaded: 325,
        }
    }

    fn progress() -> GroupProgressReport {
        GroupProgressReport {
            total_bytes: 1_000,
            total_bytes_completed: 900,
            total_bytes_completion_rate: Some(225.0),
            total_transfer_bytes: 500,
            total_transfer_bytes_completed: 400,
            total_transfer_bytes_completion_rate: Some(111.5),
            shard: Some(crate::progress_tracking::ShardUploadProgressReport {
                total_shard_bytes: 25,
                total_shard_bytes_upload_completed: 25,
                total_shards: 2,
                total_shard_validation_entries: 9,
                total_shard_validation_entries_completed: 9,
                total_shards_uploaded_to_store: 2,
                total_shards_synced: 2,
                total_shards_completed: 2,
            }),
        }
    }

    fn xorb_upload_paths() -> XorbUploadPaths {
        XorbUploadPaths {
            grant: XorbUploadPathTotals {
                count: 6,
                bytes: 240,
                duration_ms: 1_200,
            },
            direct: XorbUploadPathTotals {
                count: 2,
                bytes: 60,
                duration_ms: 300,
            },
            grant_fallbacks: 1,
            grant_unreachable: 1,
        }
    }

    fn upload_json() -> Value {
        serde_json::to_value(UploadMetrics::new(common(), &dedup(), &progress(), xorb_upload_paths(), 3_500, 500))
            .unwrap()
    }

    fn download_json() -> Value {
        let mut c = common();
        c.direction = Direction::Download.as_str();
        serde_json::to_value(DownloadMetrics::new(c)).unwrap()
    }

    fn sorted_keys(v: &Value) -> Vec<String> {
        let mut keys: Vec<_> = v.as_object().expect("metrics must be an object").keys().cloned().collect();
        keys.sort();
        keys
    }

    #[test]
    fn test_upload_key_set_is_exact() {
        assert_eq!(sorted_keys(&upload_json()), UPLOAD_KEYS);
    }

    #[test]
    fn test_download_key_set_is_exact() {
        assert_eq!(sorted_keys(&download_json()), DOWNLOAD_KEYS);
    }

    /// Guards the field-typing hazard described in the module docs.
    #[test]
    fn test_numeric_types_stable() {
        let types: std::collections::HashMap<_, _> = TYPES.iter().copied().collect();

        for doc in [upload_json(), download_json()] {
            for (key, value) in doc.as_object().unwrap() {
                let expected = types
                    .get(key.as_str())
                    .unwrap_or_else(|| panic!("key {key} missing from TYPES"));
                let actual = match value {
                    Value::Bool(_) => Kind::Bool,
                    Value::String(_) => Kind::Str,
                    Value::Number(n) if n.is_f64() => Kind::F64,
                    Value::Number(_) => Kind::U64,
                    other => panic!("{key} serialized as {other:?}; only scalars are allowed"),
                };
                assert_eq!(actual, *expected, "{key} changed JSON type");
            }
        }
    }

    #[test]
    fn test_no_null_arrays_or_nesting() {
        for doc in [upload_json(), download_json()] {
            for (key, value) in doc.as_object().unwrap() {
                assert!(
                    matches!(value, Value::Bool(_) | Value::String(_) | Value::Number(_)),
                    "{key} must be a scalar, got {value:?}"
                );
            }
        }
    }

    /// `serde_json` renders NaN and infinity as `null`, which would poison the field's type.
    #[test]
    fn test_ratios_are_finite_for_degenerate_inputs() {
        assert_eq!(ratio(5, 0), 0.0);
        assert_eq!(ratio(0, 0), 0.0);
        assert_eq!(rate_bps(5, 0), 0.0);
        assert!(ratio(u64::MAX, 1).is_finite());
        assert!(rate_bps(u64::MAX, 1).is_finite());

        // An all-zero transfer must still produce numbers, not nulls. Built through the real
        // constructor so the rates are actually computed rather than taken from a literal.
        let empty = GroupProgressReport::default();
        let common = CommonMetrics::new(
            TransferIdentity {
                duration_ms: 0,
                peak_concurrency: 0,
                ..identity()
            },
            inputs(&empty),
        );
        let doc = serde_json::to_value(UploadMetrics::new(
            common,
            &DeduplicationMetrics::default(),
            &empty,
            XorbUploadPaths::default(),
            0,
            0,
        ))
        .unwrap();

        for (key, value) in doc.as_object().unwrap() {
            assert!(!value.is_null(), "{key} serialized as null");
        }
        assert_eq!(doc["dedup_ratio"], 0.0);
        assert_eq!(doc["compression_ratio"], 0.0);
        assert_eq!(doc["throughput_bps"], 0.0);
    }

    /// Nothing identifying may reach the wire. The server derives repo and user from the JWT.
    #[test]
    fn test_no_pii_in_payload() {
        let doc = serde_json::to_string(&upload_json()).unwrap();
        for sentinel in [
            "/home/",
            "/Users/",
            "C:\\",
            ".safetensors",
            "secret-repo",
            "user@example.com",
            "Bearer ",
        ] {
            assert!(!doc.contains(sentinel), "payload leaked {sentinel}: {doc}");
        }
    }

    #[test]
    fn test_derived_values() {
        let doc = upload_json();
        // 400 deduped of 1000 logical.
        assert_eq!(doc["dedup_ratio"], 0.4);
        // 300 xorb bytes from 600 new bytes.
        assert_eq!(doc["compression_ratio"], 0.5);
        // 400 wire bytes over 4s.
        assert_eq!(doc["throughput_bps"], 100.0);
        assert_eq!(doc["shards_total"], 2);
        assert_eq!(doc["shard_validation_entries"], 9);
        assert_eq!(doc["grant_xorb_upload_count"], 6);
        assert_eq!(doc["grant_xorb_upload_bytes"], 240);
        assert_eq!(doc["grant_xorb_upload_ms"], 1_200);
        assert_eq!(doc["direct_xorb_upload_count"], 2);
        assert_eq!(doc["direct_xorb_upload_bytes"], 60);
        assert_eq!(doc["direct_xorb_upload_ms"], 300);
        assert_eq!(doc["grant_fallback_count"], 1);
        assert_eq!(doc["grant_unreachable_count"], 1);
    }

    /// Absent shard progress reads as zero rather than dropping the keys.
    #[test]
    fn test_missing_shard_progress_reads_as_zero() {
        let doc = serde_json::to_value(UploadMetrics::new(
            common(),
            &dedup(),
            &GroupProgressReport::default(),
            xorb_upload_paths(),
            0,
            0,
        ))
        .unwrap();
        assert_eq!(doc["shards_total"], 0);
        assert_eq!(doc["shards_completed"], 0);
        assert_eq!(doc["shard_validation_entries"], 0);
        assert_eq!(sorted_keys(&doc), UPLOAD_KEYS);
    }

    /// A missing EWMA reads as zero, never as `null`, so the type never varies.
    #[test]
    fn test_absent_ewma_rate_is_zero_not_null() {
        let mut p = progress();
        p.total_transfer_bytes_completion_rate = None;

        let metrics = CommonMetrics::new(identity(), inputs(&p));
        assert_eq!(metrics.ewma_throughput_bps, 0.0);
        assert_eq!(serde_json::to_value(&metrics).unwrap()["ewma_throughput_bps"], 0.0);
    }

    /// The wall-clock rates are computed from the identity's duration, not the EWMA.
    #[test]
    fn test_throughput_computed_from_duration() {
        let metrics = CommonMetrics::new(identity(), inputs(&progress()));
        // 400 wire bytes and 900 logical bytes over 4000ms.
        assert_eq!(metrics.throughput_bps, 100.0);
        assert_eq!(metrics.logical_throughput_bps, 225.0);
    }

    /// A transfer that somehow reports no elapsed time must not divide by zero.
    #[test]
    fn test_zero_duration_yields_zero_rates() {
        let metrics = CommonMetrics::new(
            TransferIdentity {
                duration_ms: 0,
                ..identity()
            },
            inputs(&progress()),
        );
        assert_eq!(metrics.throughput_bps, 0.0);
        assert_eq!(metrics.logical_throughput_bps, 0.0);
    }

    #[test]
    fn test_expansion_ratio_uses_completed_bytes() {
        let doc = download_json();
        // 900 logical bytes produced from 400 wire bytes.
        assert_eq!(doc["expansion_ratio"], 2.25);
    }
}
